<?php
// 引入 phpseclib 库
require 'vendor/autoload.php';

// 配置连接信息
$ftp_server = "ftp.tebi.io";
$ftp_port = 21; // FTP 端口
$ftp_user_name = "改成你的Key";// 填写您的钥匙 Key
$ftp_user_pass = "Secret Key";// 填写您的密码 Secret Key
$ftp_directory = "/imgs66"; // 固定上传目录 这里填您的桶名称

// 获取当前时间，按年月日创建子文件夹
$time_folder = date('Y/m');
$upload_path = $ftp_directory . '/' . $time_folder;

// 设置允许上传的文件类型
$allowed_types = ['jpg', 'jpeg', 'png', 'gif', 'webp']; // 限制文件类型

// 检查是否存在文件上传
if (isset($_FILES['files']) && is_array($_FILES['files']['tmp_name'])) {
    // 多文件上传
    $files = $_FILES['files'];
    $file_urls = [];

    // 连接 FTP 服务器
    $ftp_conn = ftp_connect($ftp_server, $ftp_port);
    if (!$ftp_conn) {
        echo json_encode(["error" => "FTP 连接失败"]);
        exit;
    }

    // FTP 登录
    if (!ftp_login($ftp_conn, $ftp_user_name, $ftp_user_pass)) {
        echo json_encode(["error" => "FTP 登录失败"]);
        ftp_close($ftp_conn);
        exit;
    }

    // 设置 FTP 被动模式
    ftp_pasv($ftp_conn, true);

    // 确保目标目录存在
    if (!ftp_chdir($ftp_conn, $upload_path)) {
        if (!ftp_mkdir($ftp_conn, $upload_path)) {
            echo json_encode(["error" => "FTP 创建目录失败"]);
            ftp_close($ftp_conn);
            exit;
        }
    }

    // 遍历所有上传文件
    foreach ($files['tmp_name'] as $key => $file_tmp) {
        $file_name = $files['name'][$key];
        $file_type = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));

        if (!in_array($file_type, $allowed_types)) {
            echo json_encode(["error" => "不支持的文件类型: $file_name"]);
            exit;
        }

        // 给文件名加上当前时间戳并确保文件名长度为10位
        $timestamp = time();
        $new_file_name = substr($timestamp . '_' . $file_name, 0, 10) . '.' . $file_type;

        // 文件上传路径
        $file_upload_path = $upload_path . '/' . $new_file_name;

        // 上传文件到 FTP
        if (!ftp_put($ftp_conn, $file_upload_path, $file_tmp, FTP_BINARY)) {
            echo json_encode(["error" => "FTP 文件上传失败: $file_name"]);
            ftp_close($ftp_conn);
            exit;
        }

        // 保存文件 URL
        $file_urls[] = "https://s3.tebi.io/$file_upload_path";
    }

    // 关闭 FTP 连接
    ftp_close($ftp_conn);

    // 返回成功的响应
    echo json_encode([
        "success" => true,
        "file_urls" => $file_urls
    ]);

} elseif (isset($_FILES['file'])) {
    // 单文件上传处理
    $file = $_FILES['file'];

    // 获取文件信息
    $file_name = $file['name'];
    $file_tmp = $file['tmp_name'];
    $file_type = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));

    if (!in_array($file_type, $allowed_types)) {
        echo json_encode(["error" => "不支持的文件类型: $file_name"]);
        exit;
    }

    // 给文件名加上当前时间戳并确保文件名长度为10位
    $timestamp = time();
    $new_file_name = substr($timestamp . '_' . $file_name, 0, 10) . '.' . $file_type;

    // 文件上传路径
    $file_upload_path = $upload_path . '/' . $new_file_name;

    // 连接 FTP 服务器
    $ftp_conn = ftp_connect($ftp_server, $ftp_port);
    if (!$ftp_conn) {
        echo json_encode(["error" => "FTP 连接失败"]);
        exit;
    }

    // FTP 登录
    if (!ftp_login($ftp_conn, $ftp_user_name, $ftp_user_pass)) {
        echo json_encode(["error" => "FTP 登录失败"]);
        ftp_close($ftp_conn);
        exit;
    }

    // 设置 FTP 被动模式
    ftp_pasv($ftp_conn, true);

    // 确保目标目录存在
    if (!ftp_chdir($ftp_conn, $upload_path)) {
        if (!ftp_mkdir($ftp_conn, $upload_path)) {
            echo json_encode(["error" => "FTP 创建目录失败"]);
            ftp_close($ftp_conn);
            exit;
        }
    }

    // 上传文件到 FTP
    if (!ftp_put($ftp_conn, $file_upload_path, $file_tmp, FTP_BINARY)) {
        echo json_encode(["error" => "FTP 文件上传失败: $file_name"]);
        ftp_close($ftp_conn);
        exit;
    }

    // 返回文件 URL
    echo json_encode([
        "success" => true,
        "file_url" => "https://s3.tebi.io/$file_upload_path"
    ]);

    // 关闭 FTP 连接
    ftp_close($ftp_conn);

} else {
    // 返回 reset 指示，告诉前端清除状态
    echo json_encode(["reset" => true]);
}
?>
